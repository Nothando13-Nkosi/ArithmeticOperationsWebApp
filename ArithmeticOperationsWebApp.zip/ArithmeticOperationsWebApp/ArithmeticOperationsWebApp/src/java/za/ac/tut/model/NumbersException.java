package za.ac.tut.model;

/**
 *
 * @author Nothando
 */
public class NumbersException extends Exception{
    public NumbersException(String errorMsg)
    {
        super(errorMsg);
    }
    
}
