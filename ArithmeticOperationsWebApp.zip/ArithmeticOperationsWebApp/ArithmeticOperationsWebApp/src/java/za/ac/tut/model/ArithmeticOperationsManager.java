package za.ac.tut.model;

/**
 *
 * @author Nothando
 */
public class ArithmeticOperationsManager implements ArithmeticOperationsInterface{

    @Override
    public int add(int num1, int num2) throws NumbersException{
        if(isValid(num1,num2))
        {
            return (num1 + num2);
        }
        else
        {
            throw new NumbersException("The number must be positive" + num1 + "," + num2);
        }
       
    }
    private boolean isValid(int num1,int num2)
    {
        boolean valid = false;
        if(num1 > 0 && num2 > 0)
        {
            valid = true;
        }
        return valid;
    }
    
    
}
