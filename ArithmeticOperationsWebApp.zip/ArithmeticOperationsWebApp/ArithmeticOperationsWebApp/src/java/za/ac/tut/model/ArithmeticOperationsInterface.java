package za.ac.tut.model;

/**
 *
 * @author Nothando
 */
public interface ArithmeticOperationsInterface {
    public int add(int num1, int num2) throws NumbersException;
    
}
