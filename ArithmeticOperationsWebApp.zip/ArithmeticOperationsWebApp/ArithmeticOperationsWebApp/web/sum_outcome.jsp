<%-- 
    Document   : sum_outcome
    Created on : Mar 10, 2026, 4:38:26 PM
    Author     : Nothando
--%>

<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Sum Outcome Page</title>
    </head>
    <body>
        <h1>Sum</h1>
        <%
            int num1 = (Integer)request.getAttribute("num1");
            int num2 = (Integer)request.getAttribute("num2");
            int sum = (Integer)request.getAttribute("sum");
        %>
        
        <p>
            The sum of <b><%=num1%></<b> and <b><%=num2%></b> is <b><%=sum%></b>
        </p>
        <p>
            Please click <a href="index.html">here</a> to go back to main page.
        </p>
    </body>
</html>
