<%-- 
    Document   : negative_numbers_error
    Created on : Mar 10, 2026, 10:05:14 PM
    Author     : Nothando
--%>

<%@page isErrorPage="true" contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Negative Numbers Exception Page</title>
    </head>
    <body>
        <h1>Negative Numbers Exception</h1>
        <%
            String msg = (String)request.getAttribute("msg");
        %>
        <p>
            <b>Error message --> <%=msg%></b>
        </p>
        <p>
            Please click <a href="index.html">here</a> to go back to main page.
        </p>
    </body>
</html>
