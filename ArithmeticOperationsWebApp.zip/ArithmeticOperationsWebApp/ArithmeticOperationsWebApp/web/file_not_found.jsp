<%-- 
    Document   : file_not_found
    Created on : Mar 10, 2026, 3:08:35 PM
    Author     : Nothando
--%>

<%@page isErrorPage="true" contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>File Not Found Error Page</title>
    </head>
    <body>
        <h1>File not found error</h1>
        <p>
            The requested resource was not found.
        </p>
        <p>
            Please click <a href="index.html">here</a> to go back to main page.
        </p>
    </body>
</html>
