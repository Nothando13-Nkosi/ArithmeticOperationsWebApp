<%-- 
    Document   : number_format_error
    Created on : Mar 10, 2026, 3:39:27 PM
    Author     : Nothando
--%>

<%@page isErrorPage="true" contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Number Format Exception Page</title>
    </head>
    <body>
        <h1>Number Format Exception</h1>
        <%
            String errorMsg = exception.getMessage();
        %>
        <p>
            <b>Error message ---> <%=errorMsg%></b>
        </p>
        <p>
            Please click <a href="index.html">here</a> to go back to main page.
        </p>
    </body>
</html>
